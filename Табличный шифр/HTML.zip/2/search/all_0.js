var searchData=
[
  ['cipher_5ferror_0',['cipher_error',['../classcipher__error.html',1,'']]]
];