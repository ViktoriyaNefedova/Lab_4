var searchData=
[
  ['modalphacipher_10',['modAlphaCipher',['../classmodAlphaCipher.html#a4f0a86c20f5d836f66cb1e640d875e6b',1,'modAlphaCipher::modAlphaCipher()=delete'],['../classmodAlphaCipher.html#a5e2b42f76c91038870412d0b14d31544',1,'modAlphaCipher::modAlphaCipher(const wstring &amp;skey)']]]
];
